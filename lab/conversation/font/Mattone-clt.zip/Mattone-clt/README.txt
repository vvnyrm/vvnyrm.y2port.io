## License
This typeface is available under the SIL Open Font License v1.1
See [OFL.txt] for more details.

## About Author
Collletttivo is an Open Source type foundry designing and distributing digital typefaces. 

## Permissions
You can use this typeface for all personal and commercial works. Remember to credit the original designer and the foundry when publishing your work featuring Collletttivo fonts. 

## Web Usage
See [web/Hosting for Web.txt] for more details.