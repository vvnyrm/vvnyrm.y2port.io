Grotesk is a trademark of Frank Adebiaye (fadebiaye@gmail.com) (2010).
